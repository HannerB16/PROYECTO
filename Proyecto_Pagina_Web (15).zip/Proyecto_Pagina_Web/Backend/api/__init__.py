from flask import Blueprint

# Importar blueprints individuales
from .auth import auth_bp
from .admin import admin_bp
from .users import users_bp
from .devices import devices_bp
from .login import login_bp

# Crear blueprint raíz de la API
api_bp = Blueprint('api_bp', __name__, url_prefix='/api')

# Registrar blueprints específicos dentro del blueprint general
api_bp.register_blueprint(auth_bp)
api_bp.register_blueprint(admin_bp)
api_bp.register_blueprint(users_bp)
api_bp.register_blueprint(devices_bp)
api_bp.register_blueprint(login_bp)
