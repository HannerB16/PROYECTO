# security.py

import re
from flask import request, abort
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer
from flask_wtf import CSRFProtect

# CSRF protection (debes inicializarlo en app.py con csrf.init_app(app))
csrf = CSRFProtect()

# Serializer para tokens seguros (correo/verificación/restablecimiento)
def get_serializer(secret_key):
    return URLSafeTimedSerializer(secret_key)


# Validación de contraseñas fuertes
def validar_password_segura(password: str) -> bool:
    """
    Verifica que la contraseña tenga al menos:
    - 8 caracteres
    - una mayúscula
    - una minúscula
    - un número
    - un carácter especial
    """
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False
    return True


# Hash de contraseña
def generar_hash_password(password: str) -> str:
    return generate_password_hash(password)


# Verificación de contraseña
def verificar_password(password: str, hash_password: str) -> bool:
    return check_password_hash(hash_password, password)


# Protección anti fuerza bruta básica (podrías expandirlo con Redis o DB)
bloqueos_ip = {}

def proteger_fuerza_bruta(ip, max_intentos=5):
    intentos = bloqueos_ip.get(ip, 0)
    if intentos >= max_intentos:
        abort(403, description="Demasiados intentos fallidos. Intenta más tarde.")
    bloqueos_ip[ip] = intentos + 1


def resetear_intentos(ip):
    if ip in bloqueos_ip:
        bloqueos_ip.pop(ip)
