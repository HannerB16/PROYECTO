from datetime import datetime, timedelta
from sqlalchemy import func
from flask import current_app
from extensions import db


class AnalyticsService:
    def __init__(self):
        self.db = db

    def get_user_login_counts(self, days=7):
        """
        Retorna un diccionario con la cantidad de logins por día en los últimos N días.
        """
        from models import LoginHistory

        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        results = (
            self.db.session.query(
                func.date(LoginHistory.login_time).label('day'),
                func.count(LoginHistory.id).label('logins')
            )
            .filter(LoginHistory.login_time >= start_date)
            .group_by(func.date(LoginHistory.login_time))
            .order_by(func.date(LoginHistory.login_time))
            .all()
        )

        return {str(day): logins for day, logins in results}

    def get_active_users(self):
        """
        Retorna el número total de usuarios activos en el sistema.
        """
        from models import User

        return self.db.session.query(User).filter_by(is_active=True).count()

    def get_failed_login_attempts(self, hours=24):
        """
        Retorna la cantidad de intentos de login fallidos en las últimas N horas.
        """
        from models import LoginHistory

        since = datetime.utcnow() - timedelta(hours=hours)
        return (
            self.db.session.query(LoginHistory)
            .filter(LoginHistory.successful == False, LoginHistory.login_time >= since)
            .count()
        )

    def get_most_used_devices(self, limit=5):
        """
        Retorna los dispositivos más utilizados para iniciar sesión.
        """
        from models import Device

        results = (
            self.db.session.query(Device.device_type, func.count(Device.id).label('count'))
            .group_by(Device.device_type)
            .order_by(func.count(Device.id).desc())
            .limit(limit)
            .all()
        )

        return [{"device": r.device_type, "count": r.count} for r in results]


# Instancia global
analytics_service = AnalyticsService()
