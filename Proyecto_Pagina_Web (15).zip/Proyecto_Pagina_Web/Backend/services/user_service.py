from sqlalchemy.exc import SQLAlchemyError
from models import User, Device, Session
from extensions import db
from services.log_service import log_service
from services.notification_service import notification_service
from utils.password_utils import is_strong_password, hash_password, verify_password

class UserService:

    def create_user(self, username, email, password):
        try:
            if not is_strong_password(password):
                return {"error": "La contraseña no cumple con los requisitos de seguridad"}, 400

            if User.query.filter_by(email=email).first():
                return {"error": "El correo electrónico ya está en uso"}, 400

            if User.query.filter_by(username=username).first():
                return {"error": "El nombre de usuario ya está en uso"}, 400

            new_user = User(
                username=username,
                email=email,
                password_hash=hash_password(password)
            )

            db.session.add(new_user)
            db.session.commit()

            log_service.log_event(
                action="Registro de usuario",
                description=f"Nuevo usuario registrado: {username}",
                user_id=new_user.id
            )

            notification_service.send_welcome_email(email, username)

            return {"message": "Usuario registrado exitosamente"}, 201

        except SQLAlchemyError as e:
            db.session.rollback()
            log_service.log_error("Error al crear usuario", str(e))
            return {"error": "Error en el servidor"}, 500

    def authenticate_user(self, email, password):
        try:
            user = User.query.filter_by(email=email).first()
            if user and verify_password(password, user.password_hash):
                return user
            return None
        except SQLAlchemyError as e:
            log_service.log_error("Error durante autenticación", str(e))
            return None

    def change_password(self, user_id, old_password, new_password):
        try:
            user = User.query.get(user_id)
            if not user:
                return {"error": "Usuario no encontrado"}, 404

            if not verify_password(old_password, user.password_hash):
                return {"error": "Contraseña actual incorrecta"}, 401

            if not is_strong_password(new_password):
                return {"error": "La nueva contraseña no es segura"}, 400

            user.password_hash = hash_password(new_password)
            db.session.commit()

            log_service.log_event(
                action="Cambio de contraseña",
                description="El usuario cambió su contraseña",
                user_id=user.id
            )

            notification_service.send_password_change_alert(user.email)

            return {"message": "Contraseña actualizada exitosamente"}, 200

        except SQLAlchemyError as e:
            db.session.rollback()
            log_service.log_error("Error al cambiar contraseña", str(e))
            return {"error": "Error del servidor"}, 500

    def get_user_profile(self, user_id):
        try:
            user = User.query.get(user_id)
            if not user:
                return None
            return {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "created_at": user.created_at.strftime('%Y-%m-%d %H:%M:%S')
            }
        except SQLAlchemyError as e:
            log_service.log_error("Error al obtener perfil de usuario", str(e))
            return None

    def get_all_users(self):
        try:
            users = User.query.all()
            return [{
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "created_at": u.created_at.strftime('%Y-%m-%d %H:%M:%S')
            } for u in users]
        except SQLAlchemyError as e:
            log_service.log_error("Error al listar usuarios", str(e))
            return []

# Instancia global
user_service = UserService()

