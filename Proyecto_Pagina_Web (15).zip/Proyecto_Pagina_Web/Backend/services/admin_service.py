# services/admin_service.py

from sqlalchemy.exc import SQLAlchemyError
from models import Usuario
from extensions import db
from werkzeug.security import generate_password_hash

class AdminService:
    def __init__(self, session):
        self.session = session

    def listar_usuarios(self):
        try:
            return self.session.query(Usuario).all()
        except SQLAlchemyError as e:
            raise Exception(f"Error al listar usuarios: {e}")

    def obtener_usuario_por_id(self, usuario_id):
        try:
            return self.session.query(Usuario).filter_by(id=usuario_id).first()
        except SQLAlchemyError as e:
            raise Exception(f"Error al obtener usuario: {e}")

    def actualizar_usuario(self, usuario_id, nuevos_datos):
        try:
            usuario = self.obtener_usuario_por_id(usuario_id)
            if not usuario:
                return None

            usuario.username = nuevos_datos.get("username", usuario.username)
            usuario.email = nuevos_datos.get("email", usuario.email)
            usuario.rol = nuevos_datos.get("rol", usuario.rol)
            self.session.commit()
            return usuario
        except SQLAlchemyError as e:
            self.session.rollback()
            raise Exception(f"Error al actualizar usuario: {e}")

    def cambiar_contrasena(self, usuario_id, nueva_contrasena):
        try:
            usuario = self.obtener_usuario_por_id(usuario_id)
            if not usuario:
                return None
            usuario.password = generate_password_hash(nueva_contrasena)
            self.session.commit()
            return usuario
        except SQLAlchemyError as e:
            self.session.rollback()
            raise Exception(f"Error al cambiar contraseña: {e}")

    def eliminar_usuario(self, usuario_id):
        try:
            usuario = self.obtener_usuario_por_id(usuario_id)
            if not usuario:
                return False
            self.session.delete(usuario)
            self.session.commit()
            return True
        except SQLAlchemyError as e:
            self.session.rollback()
            raise Exception(f"Error al eliminar usuario: {e}")
admin_service = AdminService()