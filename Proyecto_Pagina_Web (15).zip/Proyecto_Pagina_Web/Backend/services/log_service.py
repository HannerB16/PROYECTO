# services/log_service.py

import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from models import Log
from database import get_db_session
from sqlalchemy.exc import SQLAlchemyError
import os

class LogService:
    def __init__(self, log_dir='logs', max_bytes=5 * 1024 * 1024, backup_count=5):
        os.makedirs(log_dir, exist_ok=True)

        self.logger = logging.getLogger('SistemaSeguridad')
        self.logger.setLevel(logging.INFO)

        handler = RotatingFileHandler(
            filename=os.path.join(log_dir, 'registro_eventos.log'),
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding='utf-8'
        )
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)

        if not self.logger.handlers:
            self.logger.addHandler(handler)

    def registrar_evento(self, tipo, descripcion, user_id=None, dispositivo_id=None, nivel='INFO'):
        """
        Registra un evento en la base de datos y el archivo de logs.
        """
        session = get_db_session()
        try:
            evento = Log(
                tipo=tipo,
                descripcion=descripcion,
                user_id=user_id,
                dispositivo_id=dispositivo_id,
                fecha=datetime.utcnow()
            )
            session.add(evento)
            session.commit()

            mensaje = f"{tipo} | Usuario: {user_id} | Dispositivo: {dispositivo_id} | {descripcion}"

            if nivel == 'INFO':
                self.logger.info(mensaje)
            elif nivel == 'WARNING':
                self.logger.warning(mensaje)
            elif nivel == 'ERROR':
                self.logger.error(mensaje)
            elif nivel == 'DEBUG':
                self.logger.debug(mensaje)
            else:
                self.logger.info(mensaje)

        except SQLAlchemyError as e:
            session.rollback()
            self.logger.error(f"Fallo al registrar evento en DB: {str(e)}")
        finally:
            session.close()

    def obtener_logs_usuario(self, user_id):
        """
        Retorna todos los logs de un usuario.
        """
        session = get_db_session()
        try:
            return session.query(Log).filter_by(user_id=user_id).order_by(Log.fecha.desc()).all()
        except SQLAlchemyError as e:
            raise Exception(f"Error al obtener logs: {str(e)}")
        finally:
            session.close()

# Instancia global
log_service = LogService()
