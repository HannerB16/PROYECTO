# services/password_service.py

import re
from werkzeug.security import generate_password_hash
from models import Usuario
from database import get_db_session
from services.notification_service import notification_service
from sqlalchemy.exc import SQLAlchemyError

class PasswordService:

    def verificar_fortaleza(self, password):
        """
        Verifica que la contraseña cumpla con los requisitos de seguridad.
        """
        if len(password) < 8:
            return False, "La contraseña debe tener al menos 8 caracteres"
        if not re.search(r"[A-Z]", password):
            return False, "Debe contener al menos una letra mayúscula"
        if not re.search(r"[a-z]", password):
            return False, "Debe contener al menos una letra minúscula"
        if not re.search(r"[0-9]", password):
            return False, "Debe contener al menos un número"
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
            return False, "Debe contener al menos un carácter especial"
        return True, "Contraseña válida"

    def cambiar_password(self, user_id, old_password, new_password):
        """
        Cambia la contraseña del usuario si la actual es válida.
        """
        session = get_db_session()
        try:
            user = session.query(Usuario).filter_by(id=user_id).first()
            if not user or not user.verificar_password(old_password):
                return False, "La contraseña actual es incorrecta"

            valida, mensaje = self.verificar_fortaleza(new_password)
            if not valida:
                return False, mensaje

            user.password = generate_password_hash(new_password)
            session.commit()

            notification_service.enviar_email(
                destinatario=user.email,
                asunto="Cambio de contraseña exitoso",
                plantilla="EmailCambioContraseña.html",
                datos={"usuario": user.username}
            )

            return True, "Contraseña cambiada con éxito"
        except SQLAlchemyError as e:
            session.rollback()
            return False, f"Error de base de datos: {e}"
        finally:
            session.close()

# Instancia global
password_service = PasswordService()
