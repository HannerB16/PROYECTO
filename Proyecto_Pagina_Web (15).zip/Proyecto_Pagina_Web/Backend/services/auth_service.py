from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import SQLAlchemyError
from flask_jwt_extended import create_access_token
from datetime import datetime, timedelta
from models import Usuario
from database import get_db_session
from utils.email_utils import enviar_correo_verificacion
from utils.token_utils import generar_token_unico

class AuthService:
    def __init__(self):
        pass

    def registrar_usuario(self, username, email, password):
        session = get_db_session()
        try:
            if session.query(Usuario).filter_by(username=username).first():
                return {"error": "El nombre de usuario ya está en uso"}, 400
            if session.query(Usuario).filter_by(email=email).first():
                return {"error": "El correo electrónico ya está en uso"}, 400

            hashed_password = generate_password_hash(password)
            token_verificacion = generar_token_unico()
            nuevo_usuario = Usuario(
                username=username,
                email=email,
                password=hashed_password,
                verificado=False,
                token_verificacion=token_verificacion,
                creado_en=datetime.utcnow()
            )

            session.add(nuevo_usuario)
            session.commit()

            enviar_correo_verificacion(email, token_verificacion)

            return {"message": "Registro exitoso. Por favor verifica tu correo."}, 201
        except SQLAlchemyError as e:
            session.rollback()
            return {"error": str(e)}, 500
        finally:
            session.close()

    def verificar_cuenta(self, token):
        session = get_db_session()
        try:
            usuario = session.query(Usuario).filter_by(token_verificacion=token).first()
            if not usuario:
                return {"error": "Token inválido o expirado"}, 400

            usuario.verificado = True
            usuario.token_verificacion = None
            session.commit()

            return {"message": "Cuenta verificada exitosamente"}, 200
        except SQLAlchemyError as e:
            session.rollback()
            return {"error": str(e)}, 500
        finally:
            session.close()

    def iniciar_sesion(self, email, password):
        session = get_db_session()
        try:
            usuario = session.query(Usuario).filter_by(email=email).first()
            if not usuario or not check_password_hash(usuario.password, password):
                return {"error": "Credenciales inválidas"}, 401
            if not usuario.verificado:
                return {"error": "La cuenta no está verificada"}, 403

            access_token = create_access_token(identity=usuario.id, expires_delta=timedelta(hours=1))
            return {
                "message": "Inicio de sesión exitoso",
                "token": access_token,
                "rol": usuario.rol,
                "username": usuario.username
            }, 200
        except SQLAlchemyError as e:
            return {"error": str(e)}, 500
        finally:
            session.close()

    def cambiar_contrasena(self, username, old_password, new_password):
        session = get_db_session()
        try:
            usuario = session.query(Usuario).filter_by(username=username).first()
            if not usuario or not check_password_hash(usuario.password, old_password):
                return {"error": "Credenciales inválidas"}, 401

            usuario.password = generate_password_hash(new_password)
            session.commit()
            return {"message": "Contraseña cambiada exitosamente"}, 200
        except SQLAlchemyError as e:
            session.rollback()
            return {"error": str(e)}, 500
        finally:
            session.close()
auth_service = AuthService()