# services/device_service.py

from sqlalchemy.exc import SQLAlchemyError
from models import Dispositivo, Sesion, Usuario
from database import get_db_session
from utils.device_utils import parse_user_agent, obtener_ubicacion_aproximada
from utils.session_utils import registrar_sesion

class DeviceService:
    def __init__(self):
        pass

    def registrar_dispositivo_si_nuevo(self, user_id, user_agent, ip):
        """
        Registra un dispositivo si es nuevo. Si ya existe, lo omite.
        """
        session = get_db_session()
        try:
            info_dispositivo = parse_user_agent(user_agent)
            ubicacion = obtener_ubicacion_aproximada(ip)

            dispositivo_existente = session.query(Dispositivo).filter_by(
                user_id=user_id,
                so=info_dispositivo["so"],
                navegador=info_dispositivo["navegador"],
                version=info_dispositivo["version"],
                ip=ip
            ).first()

            if dispositivo_existente:
                return dispositivo_existente, False

            nuevo_dispositivo = Dispositivo(
                user_id=user_id,
                so=info_dispositivo["so"],
                navegador=info_dispositivo["navegador"],
                version=info_dispositivo["version"],
                ip=ip,
                ubicacion=ubicacion,
                confiable=False
            )
            session.add(nuevo_dispositivo)
            session.commit()
            return nuevo_dispositivo, True

        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error al registrar dispositivo: {str(e)}")
        finally:
            session.close()

    def listar_dispositivos_por_usuario(self, user_id):
        """
        Retorna todos los dispositivos vinculados a un usuario.
        """
        session = get_db_session()
        try:
            return session.query(Dispositivo).filter_by(user_id=user_id).all()
        except SQLAlchemyError as e:
            raise Exception(f"Error al obtener dispositivos: {str(e)}")
        finally:
            session.close()

    def marcar_como_confiable(self, user_id, dispositivo_id):
        """
        Marca un dispositivo como confiable para el usuario.
        """
        session = get_db_session()
        try:
            dispositivo = session.query(Dispositivo).filter_by(id=dispositivo_id, user_id=user_id).first()
            if not dispositivo:
                raise Exception("Dispositivo no encontrado o no autorizado")

            dispositivo.confiable = True
            session.commit()
            return dispositivo
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error al marcar como confiable: {str(e)}")
        finally:
            session.close()

    def eliminar_dispositivo(self, user_id, dispositivo_id):
        """
        Elimina un dispositivo del usuario.
        """
        session = get_db_session()
        try:
            dispositivo = session.query(Dispositivo).filter_by(id=dispositivo_id, user_id=user_id).first()
            if not dispositivo:
                raise Exception("Dispositivo no encontrado o no autorizado")

            session.delete(dispositivo)
            session.commit()
            return True
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error al eliminar dispositivo: {str(e)}")
        finally:
            session.close()

    def registrar_sesion(self, user_id, dispositivo_id, ip):
        """
        Registra una sesión de inicio de sesión para el historial del usuario.
        """
        return registrar_sesion(user_id, dispositivo_id, ip)

# Instancia global del servicio
device_service = DeviceService()
