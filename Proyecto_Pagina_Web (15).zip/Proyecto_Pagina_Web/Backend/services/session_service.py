import datetime
from flask import request
from sqlalchemy.exc import SQLAlchemyError
from extensions import db
from models import Session
from utils.device_utils import get_device_info
from utils.session_utils import generate_session_token, decode_session_token
from services.log_service import log_service
from services.notification_service import notification_service

class SessionService:
    def __init__(self):
        self.active_sessions = {}  # Diccionario opcional si se quiere manejar sesiones en memoria

    def register_session(self, user_id, user_email, ip_address=None):
        try:
            ip = ip_address or request.remote_addr
            device_info = get_device_info(request)
            token = generate_session_token(user_id, user_email)

            session_entry = Session(
                user_id=user_id,
                token=token,
                ip_address=ip,
                device_type=device_info.get("device_type", "desconocido"),
                browser=device_info.get("browser", "desconocido"),
                os=device_info.get("os", "desconocido"),
                user_agent=device_info.get("user_agent"),
                created_at=datetime.datetime.utcnow()
            )

            db.session.add(session_entry)
            db.session.commit()

            log_service.log_event(
                action="Inicio de sesión",
                description=f"Usuario ID {user_id} inició sesión desde {device_info.get('device_type')}",
                user_id=user_id,
                ip_address=ip
            )

            notification_service.send_login_alert(
                to_email=user_email,
                device=device_info,
                ip=ip
            )

            return token

        except SQLAlchemyError as e:
            db.session.rollback()
            log_service.log_error("Error al registrar sesión", str(e))
            return None

    def validate_session_token(self, token):
        """
        Decodifica y valida el token de sesión. Retorna user_id si es válido, o None.
        """
        data = decode_session_token(token)
        return data.get("user_id") if data else None

    def close_session(self, token):
        """
        Marca como cerrada la sesión asociada al token dado.
        """
        try:
            session_entry = Session.query.filter_by(token=token).first()
            if session_entry:
                session_entry.ended_at = datetime.datetime.utcnow()
                db.session.commit()

                log_service.log_event(
                    action="Cierre de sesión",
                    description=f"Sesión cerrada para token: {token}",
                    user_id=session_entry.user_id,
                    ip_address=session_entry.ip_address
                )

                return True
            return False

        except SQLAlchemyError as e:
            db.session.rollback()
            log_service.log_error("Error al cerrar sesión", str(e))
            return False

    def get_user_sessions(self, user_id):
        """
        Retorna el historial de sesiones de un usuario.
        """
        try:
            return Session.query.filter_by(user_id=user_id).order_by(Session.created_at.desc()).all()
        except SQLAlchemyError as e:
            log_service.log_error("Error al obtener sesiones", str(e))
            return []

# Instancia global
session_service = SessionService()
