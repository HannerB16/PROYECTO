import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Environment, FileSystemLoader, select_autoescape
from flask import current_app
from utils.email_utils import validar_correo
from extensions import db
from models import Notificacion
from datetime import datetime
import logging
import os

class NotificationService:
    def __init__(self):
        # Configurar Jinja2 para las plantillas HTML de correo
        templates_path = os.path.join(os.path.dirname(__file__), '..', 'templates', 'emails')
        self.env = Environment(
            loader=FileSystemLoader(templates_path),
            autoescape=select_autoescape(['html', 'xml'])
        )

    def enviar_correo(self, destinatario, asunto, plantilla, contexto):
        try:
            if not validar_correo(destinatario):
                raise ValueError("El correo del destinatario no es válido.")

            template = self.env.get_template(plantilla)
            contenido_html = template.render(contexto)

            mensaje = MIMEMultipart()
            mensaje['From'] = current_app.config['MAIL_SENDER']
            mensaje['To'] = destinatario
            mensaje['Subject'] = asunto

            mensaje.attach(MIMEText(contenido_html, 'html'))

            with smtplib.SMTP(current_app.config['MAIL_SERVER'], current_app.config['MAIL_PORT']) as server:
                server.starttls()
                server.login(current_app.config['MAIL_USERNAME'], current_app.config['MAIL_PASSWORD'])
                server.send_message(mensaje)

            logging.info(f"Correo enviado a {destinatario} con asunto: {asunto}")
            return True

        except Exception as e:
            logging.error(f"Error al enviar correo: {e}")
            return False

    def registrar_notificacion(self, user_id, tipo, mensaje, dispositivo=None):
        try:
            notificacion = Notificacion(
                user_id=user_id,
                tipo=tipo,
                mensaje=mensaje,
                dispositivo=dispositivo,
                fecha=datetime.utcnow()
            )
            db.session.add(notificacion)
            db.session.commit()
            logging.info(f"Notificación registrada para el usuario {user_id}")
        except Exception as e:
            logging.error(f"Error registrando notificación: {e}")
            db.session.rollback()

    def notificar_dispositivo_nuevo(self, usuario, dispositivo_info):
        if not usuario or not dispositivo_info:
            logging.warning("Faltan datos para enviar notificación de nuevo dispositivo.")
            return

        asunto = "Nuevo dispositivo detectado"
        plantilla = "EmailNuevoDispositivo.html"
        contexto = {
            "nombre": usuario.nombre,
            "correo": usuario.email,
            "fecha": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            "dispositivo": dispositivo_info.get("nombre", "Desconocido"),
            "navegador": dispositivo_info.get("navegador", "N/A"),
            "ip": dispositivo_info.get("ip", "No detectada"),
            "ubicacion": dispositivo_info.get("ubicacion", "Desconocida")
        }

        enviado = self.enviar_correo(usuario.email, asunto, plantilla, contexto)

        mensaje = f"Nuevo acceso desde dispositivo: {contexto['dispositivo']} (IP: {contexto['ip']})"
        self.registrar_notificacion(user_id=usuario.id, tipo="dispositivo_nuevo", mensaje=mensaje, dispositivo=contexto["dispositivo"])

        return enviado

# Instancia global
notification_service = NotificationService()
