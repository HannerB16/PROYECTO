# models.py

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import uuid

db = SQLAlchemy()

class Usuario(db.Model):
    __tablename__ = 'usuarios'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    rol = db.Column(db.String(20), nullable=False, default="Final")  # "Final" o "Admin"
    verificado = db.Column(db.Boolean, default=False)
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)

    dispositivos = db.relationship("Dispositivo", backref="usuario", lazy=True)
    sesiones = db.relationship("Sesion", backref="usuario", lazy=True)

    def __repr__(self):
        return f'<Usuario {self.username}>'

    def verificar_password(self, password):
        return check_password_hash(self.password_hash, password)

    def establecer_password(self, password):
        self.password_hash = generate_password_hash(password)

    def agregar_dispositivo(self, dispositivo):
        self.dispositivos.append(dispositivo)
        db.session.commit()

    def obtener_dispositivos(self):
        return self.dispositivos

    @staticmethod
    def obtener_usuario_por_email(email):
        return Usuario.query.filter_by(email=email).first()

    @staticmethod
    def obtener_usuario_por_id(user_id):
        return Usuario.query.get(user_id)


class Dispositivo(db.Model):
    __tablename__ = 'dispositivos'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    nombre = db.Column(db.String(100), nullable=False)
    ip = db.Column(db.String(45), nullable=True)
    navegador = db.Column(db.String(100), nullable=True)
    ubicacion = db.Column(db.String(100), nullable=True)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)

    usuario_id = db.Column(db.String(36), db.ForeignKey('usuarios.id'), nullable=False)

    sesiones = db.relationship("Sesion", backref="dispositivo", lazy=True)

    def __repr__(self):
        return f'<Dispositivo {self.nombre}>'

    @staticmethod
    def obtener_dispositivo_por_id(dispositivo_id):
        return Dispositivo.query.get(dispositivo_id)

    @staticmethod
    def obtener_dispositivos_por_usuario(usuario_id):
        return Dispositivo.query.filter_by(usuario_id=usuario_id).all()


class Sesion(db.Model):
    __tablename__ = 'sesiones'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    usuario_id = db.Column(db.String(36), db.ForeignKey('usuarios.id'), nullable=False)
    fecha_inicio = db.Column(db.DateTime, default=datetime.utcnow)
    fecha_fin = db.Column(db.DateTime, nullable=True)
    ip = db.Column(db.String(45), nullable=True)
    dispositivo_id = db.Column(db.String(36), db.ForeignKey('dispositivos.id'), nullable=True)

    def __repr__(self):
        return f'<Sesion {self.id} para Usuario {self.usuario_id}>'

    @staticmethod
    def registrar_sesion(usuario_id, ip, dispositivo_id):
        nueva_sesion = Sesion(usuario_id=usuario_id, ip=ip, dispositivo_id=dispositivo_id)
        db.session.add(nueva_sesion)
        db.session.commit()
        return nueva_sesion

    @staticmethod
    def finalizar_sesion(sesion_id):
        sesion = Sesion.query.get(sesion_id)
        if sesion:
            sesion.fecha_fin = datetime.utcnow()
            db.session.commit()
            return True
        return False

    @staticmethod
    def obtener_sesiones_por_usuario(usuario_id):
        return Sesion.query.filter_by(usuario_id=usuario_id).order_by(Sesion.fecha_inicio.desc()).all()
