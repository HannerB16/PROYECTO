# extensions/__init__.py

from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_login import LoginManager
from flask_mail import Mail
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager

# Instancias globales
db = SQLAlchemy()
cors = CORS()
login_manager = LoginManager()
mail = Mail()
migrate = Migrate()
jwt = JWTManager()

def init_extensions(app):
    """
    Inicializa todas las extensiones necesarias para la app Flask.
    """
    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    login_manager.init_app(app)
    mail.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    login_manager.login_view = "auth_bp.login"
    login_manager.login_message = "Por favor inicia sesión para acceder a esta página."
    login_manager.login_message_category = "info"
